grep $1 ../Player_Analysis/Notes_Player_Analysis | awk '{print $2,$3}'

